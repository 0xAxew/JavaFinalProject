package com.example.java_web_final_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaWebFinalProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
