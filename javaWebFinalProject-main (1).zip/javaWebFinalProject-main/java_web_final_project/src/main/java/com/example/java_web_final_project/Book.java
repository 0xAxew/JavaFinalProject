package com.example.myproject.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;     // Placeholder for the book's title
    private String author;    // Placeholder for the book's author
    private int pageCount;    // Placeholder for the number of pages in the book

    // Constructors, getters, and setters

    // ...
}